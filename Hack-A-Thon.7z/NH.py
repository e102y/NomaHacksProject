#reads in the data from the buzzfeed political news set and performs word counting
def strata(real):
    #change fs and fe depending on your os
    fs = "C:/Users/Trent/Desktop/Hack-A-Thon/Horne2017_FakeNewsData/Buzzfeed Political News Dataset/Fake/"
    fe = "_Fake.txt"
    if(real):
        fs = "C:/Users/Trent/Desktop/Hack-A-Thon/Horne2017_FakeNewsData/Buzzfeed Political News Dataset/Real/"
        fe = "_Real.txt"
    wc = dict()
    for i in range(1, 48):
        if(real):
            f = open(fs + str(100+i) + fe, "r")
        else:
            f = open(fs + str(i) + fe, "r")
        fc = f.read()
        fcs = fc.split()
        #fci = map(stringToInt, fcs)
        for i in fcs:
            if i in wc:
                wc[i] += 1
            else:
                wc[i] = 1
        f.close()
    return wc
def stringToInt(s):
        r = 0
        for i in s:
            r = r*100
        return r
def main():
    for i, j in strata(False).items():
        if(j > 4 and j < 250):
            print(i, ": ", j)

main()



#class defaultNN:
    
#    def train():

#    def test():

